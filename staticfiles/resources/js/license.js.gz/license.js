/*

Theme: Quick – Website UI Kit (FREE)
Version: 1.1.0
Product Page: https://webpixels.io/themes/quick-website-ui-kit
License: MIT
Author: Webpixels
Author URI: https://webpixels.io

---

Copyright 2020 Webpixels

*/
